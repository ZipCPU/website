////////////////////////////////////////////////////////////////////////////////
//
// Filename:	port.h
//
// Project:	Verilog Tutorial Example file
//
// Purpose:	Defines the communication parameters necessary for communicating
//		both with our actual hardware device, as well as with our Verilator
//	simulation.  The result is that whatever communicates with the other may
//	not know the difference (as desired).
//
//
// Creator:	Dan Gisselquist, Ph.D.
//		Gisselquist Technology, LLC
//
////////////////////////////////////////////////////////////////////////////////
//
// Written and distributed by Gisselquist Technology, LLC
//
// This program is hereby granted to the public domain.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTIBILITY or
// FITNESS FOR A PARTICULAR PURPOSE.
//
////////////////////////////////////////////////////////////////////////////////
//
//
#ifndef	PORT_H
#define	PORT_H

// There are two ways to connect: via a serial port, and via a TCP socket
// connected to a serial port.  This way, we can connect the device on one
// computer, test it, and when/if it doesn't work we can replace the device
// with the test-bench.  Across the network, no one will know any better that
// anything had changed.
#define	FPGAHOST	"localhost"	// Whatever computer is used to run this
#define	FPGAPORT	9467		// A somewhat random port number--CHANGEME

#define FPGAOPEN(V) V= new FPGA(new NETCOMMS(FPGAHOST, FPGAPORT))

#endif
