////////////////////////////////////////////////////////////////////////////////
//
// Filename: 	tbclock.h
//
// Project:	Verilog Tutorial Example file
//
// Purpose:	
//
// Creator:	Dan Gisselquist, Ph.D.
//		Gisselquist Technology, LLC
//
////////////////////////////////////////////////////////////////////////////////
//
// Written and distributed by Gisselquist Technology, LLC
//
// This program is hereby granted to the public domain.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTIBILITY or
// FITNESS FOR A PARTICULAR PURPOSE.
//
////////////////////////////////////////////////////////////////////////////////
//
//
#ifndef	TBCLOCK_H
#define	TBCLOCK_H

class	TBCLOCK	{
	unsigned long	m_increment_ps, m_now_ps, m_last_edge_ps;

public:
	TBCLOCK(void) {
		m_increment_ps = 10000; // 10 ns;

		m_now_ps = m_increment_ps+1;
		m_last_edge_ps = 0;
	}

	TBCLOCK(unsigned long increment_ps) {
		init(increment_ps);
	}

	void	init(unsigned long increment_ps) {
		set_interval_ps(increment_ps);

		// Start with the clock low, waiting on a positive edge
		m_now_ps = m_increment_ps+1;
		m_last_edge_ps = 0;
	}

	unsigned long	time_to_tick(void) {
		unsigned long	ul;
		if (m_last_edge_ps > m_now_ps) {
			// Should never happen
			ul = m_last_edge_ps - m_now_ps;
			ul /= m_increment_ps;
			return m_now_ps + ul * m_increment_ps;
		} else // if (m_last_edge + m_interval_ps > m_now) {
			return (m_last_edge_ps +   m_increment_ps - m_now_ps);
	}

	void	set_interval_ps(unsigned long interval_ps) {
		// Divide the clocks interval by two, so we can have a
		// period for raising the clock, and another for lowering
		// the clock.
		m_increment_ps = (interval_ps>>1)&-2l;
		assert(m_increment_ps > 0);
	}

	int	advance(unsigned long itime) {
		m_now_ps += itime;
		if (m_now_ps >= m_last_edge_ps + 2*m_increment_ps) {
			m_last_edge_ps += 2*m_increment_ps;
			return 1;
		} else if (m_now_ps >= m_last_edge_ps + m_increment_ps)
			return 0;
		else
			return 1;
	}

	bool	rising_edge(void) {
		if (m_now_ps == m_last_edge_ps)
			return true;
		return false;
	}

	bool	falling_edge(void) {
		if (m_now_ps == m_last_edge_ps + m_increment_ps)
			return true;
		return false;
	}
};
#endif
